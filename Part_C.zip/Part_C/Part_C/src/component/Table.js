import React from 'react'

export default function Table(props) {

  // use map function to list all the details from species
    if (props.catDetails.length > 0) {
        return (
            <table>
                <thead>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Color</th>
                    <th>weight</th>
                </thead>
                <tbody>
                {console.log(props.catDetails.name)}
                {console.log(props.catDetails.age)}
                {console.log(props.catDetails.color)}
                {console.log(props.catDetails.weight)}
                
                {/* {props.catDetails.map(x =>() {consle.log(props.catDetails.name)})} */}
                {props.catDetails.map(() => {
                    return (
                        <>
                        
                        </>
                    )
                })}
                </tbody>
            </table>
        )
    } else {
        return (<>
        </>)
    }

}
