import React from 'react'

export default function List(props) {

  // use map function to list all the types from species and make the event for cliking 
  return (
    <ul>
      {}
        {props.species.map(() => {
          return(
            <il>
              
              {
                props.species.type
                
              }
            </il>
          )
        })}
    </ul>
  )
}